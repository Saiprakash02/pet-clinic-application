from azure.identity import ClientSecretCredential
from azure.mgmt.rdbms.postgresql_flexibleservers import PostgreSQLManagementClient
from azure.core.exceptions import HttpResponseError
import re

def fetch_postgresql_databases(TENANT_ID, CLIENT_ID, CLIENT_SECRET, SUBSCRIPTION_ID):
    # Authenticate with Azure using the credentials
    try:
        credential = ClientSecretCredential(
            tenant_id=TENANT_ID,
            client_id=CLIENT_ID,
            client_secret=CLIENT_SECRET
        )
    except Exception as e:
        print(f"Failed to authenticate: {str(e)}")
        return []

    postgresql_databases_data = []

    try:
        # Create a PostgreSQL management client for flexible servers
        postgresql_client = PostgreSQLManagementClient(credential, SUBSCRIPTION_ID)
        
        # List all the PostgreSQL flexible servers in the subscription
        postgres_server_list = list(postgresql_client.servers.list())

        if not postgres_server_list:
            return ["No PostgreSQL Flexible Server Found"]

        # Loop through each server and fetch database details
        for server in postgres_server_list:
            print(f"Extracting PostgreSQL server details for: {server.name}")

            try:
                # Extract resource group name from the server's resource ID
                resource_group_name = extract_resource_group_from_id(server.id)
                
                # List databases for the current server
                databases = postgresql_client.databases.list_by_server(resource_group_name, server.name)
                
                # Convert the iterator to a list
                databases_list = list(databases)

                # Server-level information to add to the Excel file
                storage_size = server.storage.storage_size_gb if server.storage and server.storage.storage_size_gb else 'Not found'
                public_access = server.network.public_network_access if server.network and server.network.public_network_access else 'Not found'
                ha_enabled = server.high_availability.mode if server.high_availability and server.high_availability.mode else 'Not found'
                backup_enabled = "Yes" if server.backup and server.backup.backup_retention_days > 0 else "No"
                geo_redundant_backup = server.backup.geo_redundant_backup if server.backup else 'Not found'

                # Append server-level and database-level information to the list
                for db in databases_list:
                    postgresql_databases_data.append({
                        "ServerName": server.name,
                        "ResourceGroup": resource_group_name,
                        "Location": server.location,
                        "DatabaseName": db.name,
                        "Charset": db.charset if db.charset else 'Not found',
                        "Collation": db.collation if db.collation else 'Not found',
                        "CreationDate": server.system_data.created_at.strftime('%Y-%m-%d %H:%M:%S') if server.system_data and server.system_data.created_at else 'Not found',
                        "StorageSizeGB": storage_size,
                        "HighAvailability": ha_enabled,
                        "BackupEnabled": backup_enabled,
                        "GeoRedundantBackup": geo_redundant_backup,
                        "PublicAccess": public_access
                    })
            except HttpResponseError as db_error:
                print(f"Failed to list databases for server {server.name}: {str(db_error)}")
            except Exception as e:
                print(f"Error while processing server {server.name}: {str(e)}")
    
    except HttpResponseError as server_error:
        print(f"Failed to retrieve PostgreSQL servers: {str(server_error)}")
    except Exception as e:
        print(f"Error while listing PostgreSQL servers: {str(e)}")
    
    return postgresql_databases_data

def extract_resource_group_from_id(resource_id):
    """
    Helper function to extract resource group name from the resource ID.
    The resource ID format is:
    /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.DBforPostgreSQL/servers/{serverName}
    """
    match = re.search(r'/resourceGroups/([^/]+)', resource_id)
    if match:
        return match.group(1)
    else:
        raise ValueError(f"Could not extract resource group from resource ID: {resource_id}")
