from azure.identity import ClientSecretCredential
from azure.mgmt.storage import StorageManagementClient

def get_storage_account_info(TENANT_ID, CLIENT_ID, CLIENT_SECRET, SUBSCRIPTION_ID):

    credential = ClientSecretCredential(
        tenant_id=TENANT_ID,
        client_id=CLIENT_ID,
        client_secret=CLIENT_SECRET
    )

    storage_data = []
    storage_client = StorageManagementClient(credential, SUBSCRIPTION_ID)
    storage_list = list(storage_client.storage_accounts.list())  # Converted to a list for checking emptiness

    print("Extracting Storage account details")

    if not storage_list:
        print("***No Storage account Found***")
        return ["No Storage account Found"]
    
    for account in storage_list:
        print(f"Extracting details for Storage Account: {account.name}")  # Print for each storage account

        storage_data.append({
            "StorageAccountName": account.name,
            "ResourceGroup": account.id.split('/')[4],
            "Location": account.location,
            "StorageAccountType": account.sku.name,
            "AccessTier": account.access_tier if account.access_tier else 'Not found',
            "Replication": account.sku.tier if account.sku.tier else 'Not found',
            "Encryption": account.encryption.services.blob.enabled if account.encryption else 'Not found',
            "PublicAccess": account.allow_blob_public_access if account.allow_blob_public_access is not None else 'Not found',
            "Performance": account.sku.name
        })
    
    return storage_data
