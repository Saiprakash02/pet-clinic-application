from azure.identity import ClientSecretCredential
from azure.mgmt.web import WebSiteManagementClient


def get_app_services_details(tenant_id, client_id, client_secret, subscription_id):
    """
    Retrieves detailed information about Web Apps and Function Apps under the given Azure subscription.
    """
    # Authenticate with Azure
    credential = ClientSecretCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret
    )

    web_client = WebSiteManagementClient(credential, subscription_id)
    
    # Fetch all App Services (Web Apps and Function Apps)
    app_services = list(web_client.web_apps.list())
    if not app_services:
        print("***No App Services Found***")
        return [{"AppName": "No App Services Found"}]

    print("Extracting App Service details")
    app_services_data = []

    for app in app_services:
        print(f"Extracting details for App Service: {app.name}")

        # Determine App Type (Web App or Function App)
        app_type = "Function App" if "functionapp" in app.kind else "Web App"

        # Extract App Service Plan Name
        app_service_plan_name = app.server_farm_id.split("/")[-1] if app.server_farm_id else "Unknown"

        # Basic app details
        app_service_plan_id = app.server_farm_id.split("/")[-1] if app.server_farm_id else "Unknown"
        site_config = web_client.web_apps.get_configuration(app.resource_group, app.name)

        # Determine Operating System and Container Image
        if site_config.linux_fx_version:  # Linux-based app
            os_type = "Linux"
            container_image = site_config.linux_fx_version
        elif site_config.windows_fx_version:  # Windows-based app with container
            os_type = "Windows"
            container_image = site_config.windows_fx_version
        else:  # Windows-based app without container
            os_type = "Windows"
            container_image = "Not Applicable"

        # Determine publishing model (Container or Code)
        publishing_model = "Container" if site_config.linux_fx_version or site_config.windows_fx_version else "Code"

        # Determine scaling and autoscaling
        max_scale_instance = "Unknown"
        current_instance_count = "Unknown"
        auto_scale_enabled = "Unknown"

        try:
            app_service_plan = web_client.app_service_plans.get(app.resource_group, app_service_plan_id)
            max_scale_instance = app_service_plan.maximum_number_of_workers
            current_instance_count = app_service_plan.number_of_sites
            auto_scale_enabled = "Enabled" if app_service_plan.sku.tier in ["Standard", "Premium", "PremiumV2", "PremiumV3"] else "Disabled"
        except Exception as e:
            print(f"Failed to fetch App Service Plan details for {app.name}: {e}")

        # Scale out method (based on manual or autoscale configuration)
        scale_out_method = "Autoscale" if auto_scale_enabled == "Enabled" else "Manual"

        # VNet Integration
        vnet_integration = "Enabled" if app.virtual_network_subnet_id else "Disabled"

        # Fetch custom domains
        custom_domains = ", ".join(app.host_names) if app.host_names else "None"

        # Backup configuration
        backup_configuration = "Enabled" if site_config.local_my_sql_enabled else "Disabled"

        # Fetch Deployment Slots count
        deployment_slots = len(list(web_client.web_apps.list_slots(app.resource_group, app.name)))

        # Prepare data for the current app
        app_services_data.append({
            "AppName": app.name,
            "ResourceGroup": app.resource_group,
            "AppType": app_type,  # New column for App Type
            "AppServicePlanName": app_service_plan_name,
            "Location": app.location,
            "OS": os_type,  # Column for OS type
            "Container Image": container_image,
            "VNetIntegration": vnet_integration,
            "PricingTier": app_service_plan.sku.tier if app_service_plan and app_service_plan.sku else "Unknown",
            "vCPU": app_service_plan.sku.capacity if app_service_plan and app_service_plan.sku else "Unknown",
            "Memory": f"{app_service_plan.sku.size}" if app_service_plan and app_service_plan.sku else "Unknown",
            "RemoteStorage": "Enabled" if site_config.local_my_sql_enabled else "Disabled",
            "MaximumScaleInstance": max_scale_instance,
            "CurrentInstanceCount": current_instance_count,
            "ScaleOutMethod": scale_out_method,
            "AutoScaleEnabled": auto_scale_enabled,
            "PublishingModel": publishing_model,
            "DefaultDomain": app.default_host_name,
            "CustomDomains": custom_domains,
            "BackupConfiguration": backup_configuration,
            "DeploymentSlots": deployment_slots,
            "State": app.state
        })

    return app_services_data

