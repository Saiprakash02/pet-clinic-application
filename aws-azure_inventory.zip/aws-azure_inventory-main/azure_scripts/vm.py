from azure.identity import ClientSecretCredential
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.network import NetworkManagementClient

def get_vm_info(TENANT_ID, CLIENT_ID, CLIENT_SECRET, SUBSCRIPTION_ID):
    
    credential = ClientSecretCredential(
        tenant_id=TENANT_ID,
        client_id=CLIENT_ID,
        client_secret=CLIENT_SECRET
    )

    compute_client = ComputeManagementClient(credential, SUBSCRIPTION_ID)
    network_client = NetworkManagementClient(credential, SUBSCRIPTION_ID)

    # Fetch VM details
    vms_data = []
    vm_list = list(compute_client.virtual_machines.list_all())

    print("Extracting Virtual Machine details")

    if not vm_list:
        print("***No Virtual Machines Found***")
        return ["No Virtual Machines Found"]

    # Fetch VM sizes (CPU and Memory) for reference
    vm_sizes = {size.name: size for size in compute_client.virtual_machine_sizes.list(location='eastus')}  # Use any valid location

    for vm in vm_list:
        print(f"Extracting details for VM: {vm.name}")  # Print for each VM

        os_disk = vm.storage_profile.os_disk
        public_ip_addresses = []
        dns_name = 'None'  # Default to "None" if DNS name is not configured
        nsg_name = 'No'  # Default to "No" if NSG is not associated
        load_balancer_name = 'No'  # Default to "No" if no Load Balancer attached
        bastion_name = 'No'  # Default to "No" if not connected to Azure Bastion

        for nic_id in vm.network_profile.network_interfaces:
            nic = network_client.network_interfaces.get(
                nic_id.id.split('/')[4],
                nic_id.id.split('/')[-1]
            )
            
            # Check NSG association
            if nic.network_security_group:
                nsg_name = nic.network_security_group.id.split('/')[-1]  # Get the NSG name
            
            # Check Load Balancer association
            for ip_config in nic.ip_configurations:
                if ip_config.load_balancer_backend_address_pools:
                    load_balancer_name = ', '.join(
                        [lb.id.split('/')[-1] for lb in ip_config.load_balancer_backend_address_pools]
                    )
                
                # Check for public IP addresses and DNS names
                if ip_config.public_ip_address:
                    public_ip = network_client.public_ip_addresses.get(
                        ip_config.public_ip_address.id.split('/')[4],
                        ip_config.public_ip_address.id.split('/')[-1]
                    )
                    public_ip_addresses.append(public_ip.ip_address)

                    # Fetch DNS name if available
                    if public_ip.dns_settings and public_ip.dns_settings.fqdn:
                        dns_name = public_ip.dns_settings.fqdn  # Full DNS name
                    
            # Check if the VM is associated with an Azure Bastion host (Placeholder check)
            if nic.enable_accelerated_networking:  # Placeholder condition, replace as needed
                bastion_name = 'Bastion'  # Replace with actual Bastion Host name if available

        # Fetch VM instance view for status and time created
        vm_instance_view = compute_client.virtual_machines.instance_view(
            vm.id.split('/')[4],  # Resource group name
            vm.name
        )
        status = next((s.display_status for s in vm_instance_view.statuses if s.code.startswith('PowerState/')), 'Unknown')
        
        # Fetch VM image reference details for operating system
        os_offer = vm.storage_profile.image_reference.offer if vm.storage_profile.image_reference.offer else 'Not found'
        os_publisher = vm.storage_profile.image_reference.publisher if vm.storage_profile.image_reference.publisher else 'Not found'
        os_sku = vm.storage_profile.image_reference.sku if vm.storage_profile.image_reference.sku else 'Not found'
        os_version = vm.storage_profile.image_reference.version if vm.storage_profile.image_reference.version else 'Not found'

        # Get VM size details (number of CPUs and memory)
        vm_size = vm.hardware_profile.vm_size
        vm_size_details = vm_sizes.get(vm_size, None)  # Lookup the size details

        number_of_cpus = vm_size_details.number_of_cores if vm_size_details else 'Unknown'
        memory_in_gb = (vm_size_details.memory_in_mb / 1024) if vm_size_details else 'Unknown'  # Convert from MB to GB
        
        # Get Storage Account Type for OS disk
        storage_account_type = os_disk.managed_disk.storage_account_type if os_disk.managed_disk else 'Unknown'

        # Append VM details to the list
        vms_data.append({
            "VMName": vm.name,
            "ResourceGroup": vm.id.split('/')[4],
            "Location": vm.location,
            "VMSize": vm_size,
            "CPUs": number_of_cpus,  # Added column for number of CPUs
            "MemoryGB": memory_in_gb,  # Added column for memory in GB
            "OSDiskStorageType": storage_account_type,  # Updated to use storageAccountType
            "OSDiskSize": os_disk.disk_size_gb,
            "PublicIP": ", ".join(public_ip_addresses) if public_ip_addresses else 'None',
            "DNSName": dns_name,  # Fetch the DNS name from public IP
            "NSGAssociated": nsg_name,  # Name of NSG if associated, otherwise 'No'
            "LoadBalancerAttached": load_balancer_name,  # Name of Load Balancer if attached, otherwise 'No'
            "BastionConnected": bastion_name,  # Name of Bastion Host if connected, otherwise 'No'
            "Status": status,
            "AvailabilityZone": vm.zones[0] if vm.zones else 'N/A',
            "OperatingSystem": f"{os_offer} {os_sku} ({os_publisher} {os_version})",
            "TimeCreated": vm.time_created.strftime('%d/%m/%Y, %H:%M UTC') if vm.time_created else 'Unknown'
        })
    
    return vms_data
