from azure.identity import ClientSecretCredential
from azure.mgmt.rdbms.postgresql_flexibleservers import PostgreSQLManagementClient

def get_postgresql_flexi_servers(TENANT_ID, CLIENT_ID, CLIENT_SECRET, SUBSCRIPTION_ID):
    # Authenticate with Azure using the credentials
    credential = ClientSecretCredential(
        tenant_id=TENANT_ID,
        client_id=CLIENT_ID,
        client_secret=CLIENT_SECRET
    )

    postgresql_client = PostgreSQLManagementClient(credential, SUBSCRIPTION_ID)

    # Fetch PostgreSQL Flexible Server details
    postgres_servers_data = []
    postgres_server_list = list(postgresql_client.servers.list())

    print("Extracting PostgreSQL Flexible Server details")

    if not postgres_server_list:
        print("***No PostgreSQL Flexible Servers Found***")
        return ["No PostgreSQL Flexible Servers Found"]

    for server in postgres_server_list:
        print(f"Extracting details for PostgreSQL Flexible Server: {server.name}")  # Print message for each server
        postgres_servers_data.append({
            "ServerName": server.name,
            "SubscriptionID": SUBSCRIPTION_ID,
            "ResourceGroup": server.id.split('/')[4],
            "Location": server.location,
            "Version": server.version,
            "FullyQualifiedDomainName": server.fully_qualified_domain_name,
            "State": server.state,
            "AdministratorLogin": server.administrator_login,
            "StorageSizeGB": server.storage.storage_size_gb if server.storage else 'Not found',
            "BackupRetentionDays": server.backup.backup_retention_days if server.backup else 'Not found',
            "PublicNetworkAccess": server.network.public_network_access if server.network else 'Not found',
            "HighAvailabilityMode": server.high_availability.mode if server.high_availability else 'Not found',
            "SkuName": server.sku.name if server.sku else 'Not found',  
            "SkuTier": server.sku.tier if server.sku else 'Not found'  
        })

    return postgres_servers_data
