from azure.identity import ClientSecretCredential
from azure.mgmt.network import NetworkManagementClient
from azure.core.exceptions import HttpResponseError

def get_nsg_info(tenant_id, client_id, client_secret, subscription_id):
    # Authenticate using Azure credentials
    try:
        credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
    except Exception as e:
        print(f"Failed to authenticate: {str(e)}")
        return []

    nsg_data = []

    try:
        # Create a Network Management Client for fetching NSG and subnet details
        network_client = NetworkManagementClient(credential, subscription_id)

        # List all NSGs in the subscription
        nsg_list = list(network_client.network_security_groups.list_all())

        if not nsg_list:
            print("***No Network Security Groups found***")
            return ["No Network Security Groups Found"]

        # Fetch all virtual networks to search for NSG associations
        vnet_list = list(network_client.virtual_networks.list_all())

        # Loop through each NSG and gather its security rules and associated subnets
        print("Extracting NSG details")
        for nsg in nsg_list:
            print(f"Extracting details for NSG: {nsg.name}")  # Print for each NSG

            # Get security rules for the current NSG
            security_rules = nsg.security_rules or []

            # Collect all associated subnets for this NSG
            associated_subnets = []

            # Check each virtual network for subnets associated with this NSG
            for vnet in vnet_list:
                subnets = vnet.subnets or []
                for subnet in subnets:
                    # If the subnet has this NSG assigned, collect it
                    if subnet.network_security_group and subnet.network_security_group.id == nsg.id:
                        associated_subnets.append(f"{subnet.name} (VNet: {vnet.name})")

            # If no associated subnets, add "None"
            associated_subnets_str = ', '.join(associated_subnets) if associated_subnets else "None"

            # Add security rule details for each rule
            for rule in security_rules:
                # Concatenate multiple IP ranges and port ranges into a single string
                source_ips = ', '.join(rule.source_address_prefixes) if rule.source_address_prefixes else rule.source_address_prefix or 'Any'
                destination_ips = ', '.join(rule.destination_address_prefixes) if rule.destination_address_prefixes else rule.destination_address_prefix or 'Any'

                # Correctly handle multiple source and destination ports
                source_ports = ', '.join(rule.source_port_ranges) if rule.source_port_ranges else rule.source_port_range or 'Any'
                destination_ports = ', '.join(rule.destination_port_ranges) if rule.destination_port_ranges else rule.destination_port_range or 'Any'

                # Append data to the NSG list, including subnet associations
                nsg_data.append({
                    "NSGName": nsg.name,
                    "ResourceGroup": extract_resource_group_from_id(nsg.id),
                    "Location": nsg.location,
                    "RuleName": rule.name,
                    "Priority": rule.priority,
                    "Direction": rule.direction,
                    "Access": rule.access,
                    "Protocol": rule.protocol,
                    "SourceIP": source_ips,
                    "DestinationIP": destination_ips,
                    "SourcePorts": source_ports,
                    "DestinationPorts": destination_ports,
                    "Description": rule.description or "No Description",
                    "State": "Enabled" if rule.provisioning_state == "Succeeded" else "Disabled",
                    "AssociatedSubnets": associated_subnets_str  # Add associated subnets
                })

    except HttpResponseError as nsg_error:
        print(f"Failed to retrieve NSGs: {str(nsg_error)}")
    except Exception as e:
        print(f"Error while listing NSGs: {str(e)}")

    return nsg_data

def extract_resource_group_from_id(resource_id):
    """
    Helper function to extract resource group name from the resource ID.
    The resource ID format is:
    /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/...
    """
    import re
    match = re.search(r'/resourceGroups/([^/]+)', resource_id)
    if match:
        return match.group(1)
    else:
        raise ValueError(f"Could not extract resource group from resource ID: {resource_id}")
