from azure.identity import ClientSecretCredential
from azure.mgmt.network import NetworkManagementClient

def get_vnet_info(TENANT_ID, CLIENT_ID, CLIENT_SECRET, SUBSCRIPTION_ID):
    credential = ClientSecretCredential(
        tenant_id=TENANT_ID,
        client_id=CLIENT_ID,
        client_secret=CLIENT_SECRET
    )

    network_client = NetworkManagementClient(credential, SUBSCRIPTION_ID)

    vnets_data = []
    vnet_list = list(network_client.virtual_networks.list_all())

    print("Extracting VNET details")

    if not vnet_list:
        print("***No Virtual Networks Found***")
        return ["No Virtual Networks Found"]

    for vnet in vnet_list:
        print(f"Extracting details for VNet: {vnet.name}")  # Print for each VNet

        vnet_peering = [peering.name for peering in network_client.virtual_network_peerings.list(vnet.id.split('/')[4], vnet.name)]
        nsg_ids = [subnet.network_security_group.id for subnet in vnet.subnets if subnet.network_security_group]
        nsg_names = [nsg_id.split('/')[-1] for nsg_id in nsg_ids]

        subnets = list(network_client.subnets.list(vnet.id.split('/')[4], vnet.name))
        subnet_count = len(subnets)
        
        # Safely access DNS servers
        dns_servers = vnet.dhcp_options.dns_servers if vnet.dhcp_options and vnet.dhcp_options.dns_servers else "Azure provided DNS"
        connectivity = "BGP virtual network community"  # This may need to be adjusted based on actual configuration
        connected_devices = "1"  # Placeholder; real value may need to be fetched
        peerings = ", ".join(vnet_peering) if vnet_peering else "None"
        
        for subnet in subnets:
            nsg = network_client.network_security_groups.get(
                subnet.network_security_group.id.split('/')[4],
                subnet.network_security_group.id.split('/')[-1]
            ) if subnet.network_security_group else None
            
            # Corrected: Use destination_port_range and destination_port_ranges
            nsg_ports = [
                rule.destination_port_range if rule.destination_port_range 
                else ', '.join(rule.destination_port_ranges) if rule.destination_port_ranges 
                else 'Any' 
                for rule in nsg.security_rules
            ] if nsg else []

            vnets_data.append({
                "VNetName": vnet.name,
                "ResourceGroup": vnet.id.split('/')[4],
                "Location": vnet.location,
                "AddressSpace": ", ".join(vnet.address_space.address_prefixes) if vnet.address_space else 'Not found',
                "VNetPeering": peerings,
                "Subnets": subnet.name,
                "SubnetIPRange": subnet.address_prefix,
                "NSG": ", ".join(nsg_names) if nsg_names else 'Not found',
                "AllowedPorts": ", ".join(nsg_ports) if nsg_ports else 'None',
                "DNS servers": dns_servers,
                "VirtualNetworkID": vnet.id.split('/')[-1],
                "Connectivity": connectivity,
                "ConnectedDevices": connected_devices,
                "FlowTimeout": "Configure",  # Placeholder; may require further details
                "SubnetCount": subnet_count
            })
    
    return vnets_data
