from azure.identity import ClientSecretCredential
from azure.mgmt.containerservice import ContainerServiceClient
from azure.mgmt.network import NetworkManagementClient

# Function to get AKS Cluster Information
def get_aks_cluster_info(TENANT_ID, CLIENT_ID, CLIENT_SECRET, SUBSCRIPTION_ID):
    try:
        # Authenticate with Azure
        credential = ClientSecretCredential(
            tenant_id=TENANT_ID,
            client_id=CLIENT_ID,
            client_secret=CLIENT_SECRET
        )
    except Exception as e:
        print(f"Failed to authenticate: {str(e)}")
        return []

    aks_client = ContainerServiceClient(credential, SUBSCRIPTION_ID)
    network_client = NetworkManagementClient(credential, SUBSCRIPTION_ID)

    # Fetch AKS Cluster details
    aks_data = []
    try:
        aks_clusters = aks_client.managed_clusters.list()

        print("Extracting AKS Cluster details")

        if not aks_clusters:
            print("***No AKS Clusters Found***")
            return ["No AKS Clusters Found"]

        for cluster in aks_clusters:
            print(f"Extracting details for cluster: {cluster.name}")

            # Public access check
            public_access = "Public"  # Default value
            if cluster.api_server_access_profile:
                public_access = "Private" if cluster.api_server_access_profile.enable_private_cluster else "Public"

            # Encryption at Rest logic
            encryption_at_rest = "Not Found"
            if cluster.security_profile:
                encryption_at_rest = "Encryption at-rest with a platform-managed key"

            # Subnet check
            subnet_name = "Managed" if cluster.network_profile and cluster.network_profile.network_plugin == "azure" else cluster.network_profile.pod_cidr if cluster.network_profile else "Not Found"

            # Extract NSG and Ingress/Egress Rules
            nsg_name = "No NSG Found"
            ingress_egress_rules = "No Rules Found"

            # Extract subnet information from agent pool profile
            if cluster.agent_pool_profiles:
                try:
                    subnet_id = cluster.agent_pool_profiles[0].vnet_subnet_id
                    vnet_rg_name = subnet_id.split("/")[4]  # Resource group of the VNet
                    vnet_name = subnet_id.split("/")[8]  # VNet name
                    subnet_name = subnet_id.split("/")[-1]  # Subnet name

                    # Get the subnet details
                    subnet = network_client.subnets.get(vnet_rg_name, vnet_name, subnet_name)

                    if subnet.network_security_group:
                        nsg_id = subnet.network_security_group.id
                        nsg = network_client.network_security_groups.get(vnet_rg_name, nsg_id.split('/')[-1])
                        nsg_name = nsg.name

                        # Extract Ingress and Egress Rules
                        ingress_egress_rules = ""
                        for rule in nsg.security_rules:
                            rule_info = (f"Rule: {rule.name}, Direction: {rule.direction}, "
                                         f"Access: {rule.access}, Priority: {rule.priority}, "
                                         f"Protocol: {rule.protocol}, Source: {rule.source_address_prefix or '*'}, "
                                         f"Destination: {rule.destination_address_prefix or '*'}, "
                                         f"Ports: {rule.destination_port_range or '*'}")
                            ingress_egress_rules += rule_info + "\n"
                except Exception as e:
                    print(f"Error fetching NSG and Ingress/Egress rules for cluster {cluster.name}: {e}")

            # Append data for each cluster
            aks_data.append({
                "ClusterName": cluster.name,
                "SubscriptionID": SUBSCRIPTION_ID,
                "ResourceGroup": cluster.id.split('/')[4],
                "Location": cluster.location,
                "KubernetesVersion": cluster.kubernetes_version,
                "NodeResourceGroup": cluster.node_resource_group,
                "ManagedIdentity": cluster.identity.type if cluster.identity else "Not Found",
                "RBACEnabled": cluster.enable_rbac,
                "EncryptionAtRest": encryption_at_rest,
                "VirtualNetworkName": cluster.network_profile.network_plugin if cluster.network_profile else "Not Found",
                "SubnetName": subnet_name,
                "NetworkSecurityGroup": nsg_name,  # Add NSG name
                "IngressEgressRules": ingress_egress_rules,  # Add Ingress/Egress rules
                "PublicAccess": public_access  # Public or Private access
            })

    except Exception as e:
        print(f"Error while retrieving AKS Cluster information: {str(e)}")

    if not aks_data:
        print("***No AKS Cluster Information Found***")
        return ["No AKS Cluster Information Found"]

    return aks_data
