from azure.identity import ClientSecretCredential
from azure.mgmt.sql import SqlManagementClient

def get_sql_databases(TENANT_ID, CLIENT_ID, CLIENT_SECRET, SUBSCRIPTION_ID):

    credential = ClientSecretCredential(
        tenant_id=TENANT_ID,
        client_id=CLIENT_ID,
        client_secret=CLIENT_SECRET
    )

    sql_databases_data = []   
    sql_client = SqlManagementClient(credential, SUBSCRIPTION_ID)
    sql_server_list = list(sql_client.servers.list())  # Convert to list for checking emptiness

    print("Extracting SQL server details")
    
    if not sql_server_list:
        print("***No SQL server Found***")
        return ["No SQL server Found"]

    for server in sql_server_list:
        print(f"Extracting details for SQL Server: {server.name}")  # Print message for each server

        databases_list = list(sql_client.databases.list_by_server(server.resource_group_name, server.name))  # Convert to list

        if not databases_list:
            print(f"***No Databases Found for SQL Server: {server.name}***")
            sql_databases_data.append({
                "ServerName": server.name,
                "ResourceGroup": server.resource_group_name,
                "Location": server.location,
                "DatabaseName": "No Databases Found",
                "Edition": "N/A",
                "ServiceObjective": "N/A",
                "Status": "N/A",
                "Collation": "N/A",
                "CreationDate": "N/A",
                "MaxSizeBytes": "N/A",
                "RequestedServiceObjectiveName": "N/A",
                "ElasticPoolName": "N/A"
            })
            continue

        for db in databases_list:
            print(f"Extracting details for Database: {db.name}")  # Print message for each database
            sql_databases_data.append({
                "ServerName": server.name,
                "ResourceGroup": server.resource_group_name,
                "Location": server.location,
                "DatabaseName": db.name,
                "Edition": db.edition if db.edition else 'Not found',
                "ServiceObjective": db.current_service_objective_name if db.current_service_objective_name else 'Not found',
                "Status": db.status if db.status else 'Not found',
                "Collation": db.collation if db.collation else 'Not found',
                "CreationDate": db.creation_date.strftime('%Y-%m-%d %H:%M:%S') if db.creation_date else 'Not found',
                "MaxSizeBytes": db.max_size_bytes if db.max_size_bytes else 'Not found',
                "RequestedServiceObjectiveName": db.requested_service_objective_name if db.requested_service_objective_name else 'Not found',
                "ElasticPoolName": db.elastic_pool_name if db.elastic_pool_name else 'Not found'
            })
    
    return sql_databases_data
