import getpass
from aws_scripts.ec2 import list_instance_details
from aws_scripts.rds import list_rds_instances
from aws_scripts.s3 import list_S3_buckets
from aws_scripts.vpc import list_all_vpc
from aws_scripts.eks import retrieve_eks_configuration
from save_to_excel import*
from azure_scripts.vnet import get_vnet_info
from azure_scripts.vm import get_vm_info
from azure_scripts.storage_account import get_storage_account_info
from azure_scripts.sql_db import get_sql_databases
from azure_scripts.postgres_db import fetch_postgresql_databases

def Starter_page():
    logo = [
        "                                                                                  ",
        "**********************************************************************************",
        "  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * ",
        "  *                              INVENTORY TOOL                             * ",
        "------------------------------------------------------------------------------",
        "  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * ",
        "  *                                                                         * ",
        "  *                     Manage your inventory with ease!                    * ",
        "  *                                                                         * ",
        "  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * ",
    ]
    print(*logo, sep="\n")  

def get_aws_credentials():
    while True:
        access_key = input("Enter your AWS Access Key: ")
        if not access_key.strip():
            print("AWS Access Key cannot be empty. Please try again.")
            continue 
        
        secret_key = getpass.getpass("Enter your AWS Secret Key: ")
        if not secret_key.strip():
            print("AWS Secret Key cannot be empty. Please try again.")
            continue 
        
        region_name = input("Enter your AWS Region (e.g., us-east-1): ")
        if not region_name.strip():
            print("AWS Region cannot be empty. Please try again.")
            continue  

        return access_key, secret_key, region_name

def get_azure_credentials():
    while True:
        tenant_id = input("Enter your Azure Tenant ID: ")
        if not tenant_id.strip():
            print("Azure Tenant ID cannot be empty. Please try again.")
            continue 
        
        client_id = input("Enter your Azure Client ID: ")
        if not client_id.strip():
            print("Azure Client ID cannot be empty. Please try again.")
            continue 
        
        client_secret = getpass.getpass("Enter your Azure Client Secret: ")
        if not client_secret.strip():
            print("Azure Client Secret cannot be empty. Please try again.")
            continue 

        subscription_id = input("Enter your Azure subscription ID: ")
        if not subscription_id.strip():
            print("Azure subscription ID cannot be empty. Please try again.")
            continue 

        return tenant_id, client_id, client_secret , subscription_id
    
def handle_aws_choice():
    print("**************************************************")
    print("\nYou chose AWS.")
    
    access_key, secret_key, region_name = get_aws_credentials()
    print("\nAWS Credentials Entered:")
    print(f"Access Key: {access_key}")
    print(f"Secret Key: {'*' * len(secret_key)}")  
    print(f"Region: {region_name}")
    print("************Extracting Configurations*************")
    
    #Retriving AWS resource configuration.
    all_ec2_instance_info = list_instance_details(access_key, secret_key, region_name)
    all_rds_db_info = list_rds_instances(access_key, secret_key, region_name)
    all_s3_bucket_info = list_S3_buckets(access_key, secret_key, region_name)
    vpc_data, subnet_data, route_table_data, igw_data, nat_data = list_all_vpc(access_key, secret_key, region_name)
    eks_cluster_config , eks_nodegroup_config= retrieve_eks_configuration(access_key, secret_key, region_name)

    
    save_to_excel_vpc(vpc_data, subnet_data, route_table_data, igw_data, nat_data, "Networking")
    save_to_excel_common(all_ec2_instance_info, "EC2_Data")
    save_to_excel_common(all_rds_db_info, "RDS_Data")
    save_to_excel_common(all_s3_bucket_info, "S3_Data")
    save_to_excel_common(eks_cluster_config, "EKS_Cluster")
    save_to_excel_common(eks_nodegroup_config,"EKS_nodegroup")

def handle_azure_choice():
    print("**************************************************")
    print("\nYou chose Azure.")
    
    tenant_id, client_id, client_secret, subscription_id = get_azure_credentials()
    
    print("\nAzure Credentials Entered:")
    print(f"Tenant ID: {tenant_id}")
    print(f"Client ID: {client_id}")
    print(f"Client Secret: {'*' * len(client_secret)}")
    print(f"Subscription ID: {subscription_id}")
    print("************Extracting Configurations*************")
    
    all_vnet_info = get_vnet_info(tenant_id, client_id, client_secret, subscription_id)
    all_vm_info = get_vm_info(tenant_id, client_id, client_secret, subscription_id)
    all_storage_account_info = get_storage_account_info(tenant_id, client_id, client_secret, subscription_id)
    all_sql_database_info = get_sql_databases(tenant_id, client_id, client_secret, subscription_id)
    all_postgres_database_info = fetch_postgresql_databases(tenant_id, client_id, client_secret, subscription_id)
    
    save_to_excel_azure(all_vnet_info, all_vm_info, all_storage_account_info, all_sql_database_info, all_postgres_database_info)

def starter_function():
    Starter_page()
    print("Choose the cloud provider:")
    print("1. AWS")
    print("2. Azure")

    choice = input("Enter the number corresponding to your choice (1 or 2): ")
    
    if choice == '1':
        handle_aws_choice()
    elif choice == '2':
        handle_azure_choice()
    else:
        print("\nInvalid choice. Please enter 1 for AWS or 2 for Azure.")


if __name__ == "__main__":
    starter_function()
