import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font

def flatten_complex_data(df):
    for col in df.columns:
        if df[col].apply(lambda x: isinstance(x, list) or isinstance(x, dict)).any():
            df[col] = df[col].apply(lambda x: ', '.join(map(str, x)) if isinstance(x, list) else str(x) if isinstance(x, dict) else x)
    return df


def save_to_excel_vpc(vpc_data, subnet_data, route_table_data, igw_data, nat_data, sheet_name):

    vpc_df = pd.DataFrame(vpc_data)
    subnets_df = pd.DataFrame(subnet_data)
    route_tables_df = pd.DataFrame(route_table_data)
    route_tables_flatten_df = flatten_complex_data(route_tables_df)
    igws_df = pd.DataFrame(igw_data)
    nat_gateways_df = pd.DataFrame(nat_data)

    wb = Workbook()
    ws = wb.active
    excel_file = "AWS_Inventory.xlsx"
    ws.title = sheet_name

    # Helper function to write DataFrame to specific row with header
    def write_df_to_sheet(sheet, df, start_row, header):
        """Write a DataFrame to a specific row in the Excel sheet with a bold header"""
        # Write the header
        for col_num, value in enumerate(header, 1):
            cell = sheet.cell(row=start_row, column=col_num, value=value)
            cell.font = Font(bold=True) 
        # Write the DataFrame
        for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False), start=start_row + 1):
            for c_idx, value in enumerate(row, start=1):
                sheet.cell(row=r_idx, column=c_idx, value=value)

    # Write each DataFrame to the sheet at specific rows
    current_row = 1

    write_df_to_sheet(ws, vpc_df, current_row,vpc_df.columns.tolist()) #['VPC Details'] * len(vpc_df.columns)
    current_row += len(vpc_df) + 2  # Move down by the number of rows in the VPC DataFrame + 2 for spacing

    write_df_to_sheet(ws, subnets_df, current_row, subnets_df.columns.tolist())
    current_row += len(subnets_df) + 2  

    write_df_to_sheet(ws, route_tables_df, current_row, route_tables_flatten_df.columns.tolist())
    current_row += len(route_tables_df) + 2 

    write_df_to_sheet(ws, igws_df, current_row, igws_df.columns.tolist())
    current_row += len(igws_df) + 2  

    write_df_to_sheet(ws, nat_gateways_df, current_row, nat_gateways_df.columns.tolist())

    wb.save(excel_file)


def save_to_excel_common(data, sheet_name):
    
    excel_file = "AWS_Inventory.xlsx"
    wb = load_workbook(excel_file)
    data_df = pd.DataFrame(data)
    ws_rds = wb.create_sheet(title= sheet_name)

    # Write DataFrame to the new sheet
    for r_idx, row in enumerate(dataframe_to_rows(data_df, index=False, header=True), start=1):
        for c_idx, value in enumerate(row, start=1):
            if isinstance(value, (list, dict, set)):
                value = str(value)
            cell = ws_rds.cell(row=r_idx, column=c_idx, value=value)
            if r_idx == 1:  # Make header bold
                cell.font = Font(bold=True)

    wb.save(excel_file)
    print(f"{sheet_name} has been saved to {excel_file}")


def save_to_excel_azure(vnets_data, vms_data, storage_data, sql_data, postgres_data):

    excel_output = "AZURE_Inventory.xlsx"
    
    vnets_df = pd.DataFrame(vnets_data)
    vms_df = pd.DataFrame(vms_data)
    storage_df = pd.DataFrame(storage_data)
    sql_df = pd.DataFrame(sql_data)
    postgres_df = pd.DataFrame(postgres_data)

    with pd.ExcelWriter(excel_output, engine='openpyxl') as writer:
        vnets_df.to_excel(writer, sheet_name='VNets', index=False)
        vms_df.to_excel(writer, sheet_name='VMs', index=False)
        storage_df.to_excel(writer, sheet_name='StorageAccounts', index=False)
        sql_df.to_excel(writer, sheet_name='SqlDatabase', index=False)
        postgres_df.to_excel(writer, sheet_name='PostgresDatabase', index=False)

    print(f"Details have been saved to {excel_output}")
