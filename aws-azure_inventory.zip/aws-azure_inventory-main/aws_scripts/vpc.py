import boto3
import pandas as pd

def aws_authentication(access_key, secret_key, region_name):
    session = boto3.Session(aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            region_name=region_name)
  
    ec2_client = session.client('ec2')
    return ec2_client

def get_subnet_details(vpc_ids, access_key, secret_key, region_name):
    ec2_client = aws_authentication(access_key,secret_key,region_name)
    print("Extracting subnet details")
    all_subnet_info = []
    for vpc_id in vpc_ids:
        subnets_info = ec2_client.describe_subnets(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])
        subnets = subnets_info['Subnets']
        for subnet in subnets:
            all_subnet_info.append({
                'Subnet ID': subnet['SubnetId'],
                'Subnet CIDR': subnet['CidrBlock'],
                'Subnet Az': subnet['AvailabilityZone'],
                'Public Subnet':subnet['MapPublicIpOnLaunch'],
                'VPC_ID' : subnet['VpcId']
            })
        
    return all_subnet_info

def get_vpc_details(vpc_ids, access_key, secret_key, region_name):
    ec2_client = aws_authentication(access_key,secret_key,region_name)
    print("Extracting VPC details")
    all_vpc_info = []
    for vpc_id in vpc_ids:
        vpc_info = ec2_client.describe_vpcs(VpcIds=[vpc_id])
        vpc = vpc_info['Vpcs'][0]
        
        data = {
            'VPC ID': vpc['VpcId'],
            'VPC CIDR range': vpc['CidrBlock'],
            'Region': region_name,
            'State': vpc['State']
        }

        all_vpc_info.append(data)

    return all_vpc_info

def get_route_table_info(vpc_ids, access_key, secret_key, region_name):
    ec2_client = aws_authentication(access_key,secret_key,region_name)
    print("Extracting route table details")
    all_routeTable_info = []
    for vpc_id in vpc_ids:
        response = ec2_client.describe_route_tables(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])
        route_tables = response['RouteTables']
        for rt in route_tables:
            route_table_id = rt['RouteTableId']
            vpc_id = rt['VpcId']
            routes = rt.get('Routes', [])
            associations = rt.get('Associations', [])

            association_details = []
            for assoc in associations:
                association_info = {
                    'SubnetId': assoc.get('SubnetId', 'N/A')
                }
                association_details.append(association_info)

            route_table_info = {
                'route_table_id': route_table_id,
                'vpc_id': vpc_id,
                'associations': association_details[0]["SubnetId"],
                'routes': routes
            }
            all_routeTable_info.append(route_table_info)

    return all_routeTable_info
    
def get_igw_info(vpc_ids, access_key, secret_key, region_name):
    ec2_client = aws_authentication(access_key,secret_key,region_name)
    print("Extracting Internet gateway details")
    all_igw_data = []
    for vpc_id in vpc_ids:
        igws_info = ec2_client.describe_internet_gateways(Filters=[{'Name': 'attachment.vpc-id', 'Values': [vpc_id]}])
        igws = igws_info['InternetGateways']

        for igw in igws:
            igw_id = igw['InternetGatewayId']
            attachments = igw.get('Attachments', [])
        
            for attachment in attachments:
                vpc_id = attachment.get('VpcId', 'N/A')
                state = attachment.get('State', 'N/A')

                igw_info = {
                    'InternetGatewayId': igw_id,
                    'State': state,
                    'VpcId': vpc_id
                }
                all_igw_data.append(igw_info)
        
    return all_igw_data


def get_nat_info(vpc_ids,access_key,secret_key,region_name):
    ec2_client = aws_authentication(access_key,secret_key,region_name)
    print("Extracting nat gateway details")

    all_nat_data = []
    for vpc_id in vpc_ids:
        nat_gateways_info = ec2_client.describe_nat_gateways(Filters=[{'Name': 'vpc-id', 'Values': [vpc_id]}])
        nat_gateways = nat_gateways_info['NatGateways']

        for nat in nat_gateways:
            nat_gateway_id = nat['NatGatewayId']
            state = nat['State']
            subnet_id = nat.get('SubnetId', 'N/A')
            VpcId = nat.get('VpcId', 'N/A')

            addresses = nat.get('NatGatewayAddresses', [])
            for address in addresses:
                private_ip = address.get('PrivateIp', 'N/A')
                public_ip = address.get('PublicIp', 'N/A')
                network_interface_id = address.get('NetworkInterfaceId', 'N/A')

            
            nat_gateway_info = {
                'NatGatewayId': nat_gateway_id,
                'State': state,
                'SubnetId': subnet_id,
                'Vpc_ID': vpc_id,
                'private_ip': private_ip,
                'public_ip': public_ip,
                'network_interface_id': network_interface_id
            }
            all_nat_data.append(nat_gateway_info)

    return all_nat_data

def list_all_vpc(access_key, secret_key, region_name):

    ec2_client = aws_authentication(access_key,secret_key,region_name)
    
    try:
        response = ec2_client.describe_vpcs()
        vpcs = response.get('Vpcs', [])
    
        if not vpcs:
            print("***No VPCs found.***")
            return["No VPC found"]
        else:
            vpc_ids = []     
            for vpc in vpcs:
                vpc_id = vpc.get('VpcId')
                vpc_ids.append(vpc_id)
            
            all_vpc_info = {}
            vpc_data=get_vpc_details(vpc_ids, access_key, secret_key, region_name)
            subnets_data = get_subnet_details(vpc_ids, access_key, secret_key, region_name)
            route_table_data = get_route_table_info(vpc_ids, access_key, secret_key, region_name)   
            igw_data = get_igw_info(vpc_ids, access_key, secret_key, region_name)
            nat_gateway_data = get_nat_info(vpc_ids, access_key, secret_key, region_name)
            return vpc_data, subnets_data, route_table_data, igw_data, nat_gateway_data
            
    except Exception as e:
        print(f"An error occurred: {e}")
   
