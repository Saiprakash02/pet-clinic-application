import boto3

def get_instance_details(instance):
    instance_id = instance.get('InstanceId', 'N/A')
    instance_name = next((tag['Value'] for tag in instance.get('Tags', []) if tag['Key'] == 'Name'), 'N/A')
    instance_type = instance.get('InstanceType', 'N/A')
    ami_id = instance.get('ImageId', 'N/A')
    public_ips = instance.get('PublicIpAddress', 'N/A')
    private_ip = instance.get('PrivateIpAddress', 'N/A')
    instance_state = instance['State']['Name']
    availability_zone = instance['Placement']['AvailabilityZone']#instance.get('AvailabilityZone', 'N/A')
    region = availability_zone[:-1]  
    #ebs_volume_id = instance['BlockDeviceMappings'][0]['Ebs']['VolumeId']
    ebs_volume_id = instance['BlockDeviceMappings'][0]['Ebs']['VolumeId'] if 'BlockDeviceMappings' in instance and len(instance['BlockDeviceMappings']) > 0 and 'Ebs' in instance['BlockDeviceMappings'][0] and 'VolumeId' in instance['BlockDeviceMappings'][0]['Ebs'] else "NA"
    delete_on_termination = instance['BlockDeviceMappings'][0]['Ebs']['DeleteOnTermination'] if 'BlockDeviceMappings' in instance and len(instance['BlockDeviceMappings']) > 0 and 'Ebs' in instance['BlockDeviceMappings'][0] and 'DeleteOnTermination' in instance['BlockDeviceMappings'][0]['Ebs'] else "NA"
    #delete_on_termination = instance['BlockDeviceMappings'][0]['Ebs']['DeleteOnTermination']
    autoscaling_groups = [group['AutoScalingGroupName'] for group in instance.get('AutoScalingGroups', [])]
    load_balancers = [lb['LoadBalancerName'] for lb in instance.get('LoadBalancers', [])]
    vpc_id = instance.get('VpcId', 'N/A')
    subnet_id = instance.get('SubnetId', 'N/A')
    security_groups = [{'Name': sg['GroupName'], 'Id': sg['GroupId']} for sg in instance['SecurityGroups']]
    cpu_count = instance['CpuOptions']['CoreCount']
    iam_role = instance['IamInstanceProfile']['Arn'].split('/')[-1] if instance.get('IamInstanceProfile', {}) else ''
    key_pair_name = instance.get('KeyName', 'N/A')
    os_name = instance.get('PlatformDetails', 'N/A')
    monitoring_status = instance['Monitoring']['State']
    print(f"Extracting EC2 details for {instance_id} ")

    instance_details = {
        'InstanceId': instance_id,
        'InstanceName': instance_name,
        'InstanceType': instance_type,
        'ImageId': ami_id,
        'PublicIP': public_ips,
        'PrivateIP': private_ip,
        'InstanceState': instance_state,
        'AvailabilityZone': availability_zone,
        'Region': region,
        'EbsVolumeID': ebs_volume_id,
        'DeleteOnTermination':delete_on_termination,
        'AutoScalingGroups': ', '.join(autoscaling_groups),
        'LoadBalancers': ', '.join(load_balancers),
        'VpcId': vpc_id,
        'SubnetId': subnet_id,
        'SecurityGroups': ', '.join([sg['Name'] + ' (' + sg['Id'] + ')' for sg in security_groups]),
        'CpuCount': cpu_count,
        'IamRole': iam_role,
        'KeyPairName': key_pair_name,
        'OsName' : os_name,
        'Monitoring' : monitoring_status
    }
    
    return instance_details

def list_instance_details(access_key, secret_key, region_name):
  
    all_instance_details = []
    session = boto3.Session( aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            region_name=region_name)
    ec2_client = session.client('ec2')

    response = ec2_client.describe_instances()
    print("Extracting EC2 details")

    if not response['Reservations']:
        print("***No Instance Found***")
        all_instance_details.append("No Instance Found")
        return all_instance_details
    else:
        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                instance_details = get_instance_details(instance)
                all_instance_details.append(instance_details)
        
        return all_instance_details



  
