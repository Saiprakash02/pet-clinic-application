import boto3

def list_rds_instances(access_key , secret_key, region_name):
    session = boto3.Session(aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            region_name=region_name)
    rds_client = session.client('rds')
    print("Extracting RDS details")
    try:
        response = rds_client.describe_db_instances()
        instances = response.get('DBInstances', [])
        if not instances:

            print("***No RDS instances found.***")
            return ["No RDS instances found"]
        else:
            all_rds_info = get_rds_configurations(instances)
            return all_rds_info
    except Exception as e:
        print(f"Error fetching RDS instances: {e}")
        return []


def get_rds_configurations(instances):
    data = []
    for instance in instances:
        InstanceID = instance.get('DBInstanceIdentifier', 'N/A')
        print(f"Extracting RDS details for {InstanceID}")
        instance_data = {
            'Instance Identifier': instance.get('DBInstanceIdentifier', 'N/A'),
            'DB Instance Class': instance.get('DBInstanceClass', 'N/A'),
            'Engine': instance.get('Engine', 'N/A'),
            'Engine Version': instance.get('EngineVersion', 'N/A'),
            'License': instance.get('LicenseModel', 'N/A'),
            'DB Instance Status': instance.get('DBInstanceStatus', 'N/A'),
            'Allocated Storage (GB)': instance.get('AllocatedStorage', 'N/A'),
            'Storage Type': instance.get('StorageType', 'N/A'),
            'Max Allocated Storage': instance.get('MaxAllocatedStorage', 'N/A'),
            'IAMDatabase Authentication': instance.get('IAMDatabaseAuthenticationEnabled', 'N/A'),
            'Master Username': instance.get('MasterUsername', 'N/A'),
            'Endpoint Address': instance.get('Endpoint', {}).get('Address', 'N/A'),
            'Endpoint Port': instance.get('Endpoint', {}).get('Port', 'N/A'),
            'Publically Accessible': instance.get('PubliclyAccessible', 'N/A'),
            'Availability Zone': instance.get('AvailabilityZone', 'N/A'),
            'Security Group': get_security_group_info(instance), 
            'Parameter Group': get_db_parameter_group_name(instance),
            'Subnet group': instance['DBSubnetGroup']['DBSubnetGroupName'],
            'Performance Insights': instance.get('PerformanceInsightsEnabled', 'N/A'),
            'Deletion Protection': instance.get('DeletionProtection', 'N/A'),

        }
        data.append(instance_data)

    return data

def get_security_group_info(instance):
    vpc_security_groups = instance.get('VpcSecurityGroups', [])
    if not vpc_security_groups:
        return 'N/A'
    Security_group_ids = [sg['VpcSecurityGroupId'] for sg in vpc_security_groups]
    return Security_group_ids

def get_db_parameter_group_name(instance):
    db_parameter_groups = instance.get('DBParameterGroups', [])
    if not db_parameter_groups:
        return 'N/A'
    Parameter_group_names = [pg['DBParameterGroupName'] for pg in db_parameter_groups]
    return Parameter_group_names
