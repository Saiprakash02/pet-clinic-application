import boto3

def fetch_bucket_configuration(bucket_name,access_key, secret_key, region_name):
    session = boto3.Session( aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            region_name=region_name)
    s3_client = session.client('s3')
    configurations = {}

    configurations['Bucket_Name'] = 'NA'

     # Fetching bucket region
    try:
        bucket_location = s3_client.get_bucket_location(Bucket=bucket_name)
        region = bucket_location['LocationConstraint'] or 'us-east-1'  # Default to 'us-east-1' if no location constraint
    except s3_client.exceptions.ClientError:
        region = 'Unknown Region'
    configurations['Region'] = region

    # Fetching bucket CORS
    try:
        cors = s3_client.get_bucket_cors(Bucket=bucket_name)
        cors_rules = cors.get('CORSRules', [])
    except s3_client.exceptions.ClientError:
        cors_rules = 'No CORS Configuration'
    configurations['CORS'] = cors_rules

    # Fetching bucket lifecycle
    try:
        lifecycle = s3_client.get_bucket_lifecycle_configuration(Bucket=bucket_name)['Rules']
    except s3_client.exceptions.ClientError:
        lifecycle = 'No Lifecycle Configuration'
    configurations['Lifecycle'] = lifecycle

    # Fetching bucket logging
    try:
        response = s3_client.get_bucket_logging(Bucket=bucket_name)
        if 'LoggingEnabled' in response:
            logging = "Logging Enabled"
        else:
            logging = 'No Logging Configuration'
         
    except s3_client.exceptions.ClientError:
        logging = 'No Logging Configuration'
    configurations['Logging'] = logging
   

    # Fetching bucket versioning
    try:
        versioning = s3_client.get_bucket_versioning(Bucket=bucket_name)
        if 'Status' in versioning:
            versioning = versioning['Status'] 
        else:
            versioning = 'No Versioning Configuration'
    except s3_client.exceptions.ClientError:
        versioning = 'No Versioning Configuration'
    configurations['Versioning'] = versioning


    # Fetching bucket encryption
    try:
        encryption = s3_client.get_bucket_encryption(Bucket=bucket_name)
        if (encryption['ServerSideEncryptionConfiguration']):
            encryption_status = 'Encryption enabled'
        else:
            encryption_status = 'No Encryption Configuration'

    except s3_client.exceptions.ClientError:
        encryption_status = 'No Encryption Configuration'
    configurations['Encryption'] = encryption_status

    try:
        public_access_block = s3_client.get_public_access_block(Bucket=bucket_name)
        public_access_block_status = public_access_block.get('PublicAccessBlockConfiguration')

        if(public_access_block_status['BlockPublicAcls'] and public_access_block_status['RestrictPublicBuckets']):
            public_access_block_status = 'Public Access is disabled'
        else:
            public_access_block_status = 'Public Access is enabled'

    except s3_client.exceptions.ClientError:
        public_access_block_status = 'Public Access is disabled'
    configurations['Public Access Block'] = public_access_block_status


    # Fetching bucket object lock configuration
    try:
        object_lock = s3_client.get_object_lock_configuration(Bucket=bucket_name)
        object_lock_status = object_lock.get('ObjectLockConfiguration', 'No Object Lock Configuration')
    except s3_client.exceptions.ClientError:
        object_lock_status = 'No Object Lock Configuration'
    configurations['Object Lock'] = object_lock_status

    
    # Fetching bucket policy
    try:
        policy = s3_client.get_bucket_policy(Bucket=bucket_name)['Policy']
    except s3_client.exceptions.ClientError:
        policy = 'No Policy'
    configurations['Policy'] = policy

    return configurations

def list_S3_buckets(access_key,secret_key , region_name):
    session = boto3.Session( aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            region_name=region_name)
    s3_client = session.client('s3')
    print("Extracing S3 bucket details")
    response = s3_client.list_buckets()
    buckets = response.get('Buckets', [])
    bucket_names = [bucket['Name'] for bucket in buckets]
    if not bucket_names:
        print("***No buckets found.***")
        return ["No buckets found."]
    else:
        all_bucket_configurations = []
        for bucket_name in bucket_names:
            print(f"Fetching configuration for bucket: {bucket_name}")
            bucket_configuration = fetch_bucket_configuration(bucket_name , access_key ,secret_key , region_name)  
            bucket_configuration['Bucket_Name'] = bucket_name
            all_bucket_configurations.append(bucket_configuration)
        
        return all_bucket_configurations
