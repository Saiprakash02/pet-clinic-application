import boto3
import pandas as pd

def ec2_authentication(access_key, secret_key, region_name):
    session = boto3.Session(aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            region_name=region_name)
    ec2_client = session.client('ec2')
    return ec2_client


def eks_authentication(access_key, secret_key, region_name):
    session = boto3.Session(aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            region_name=region_name)
    eks_client = session.client('eks')
    return eks_client


def list_eks_cluster(access_key, secret_key, region_name):
    eks_client = eks_authentication(access_key, secret_key, region_name)
    response = eks_client.list_clusters()
    cluster_names = response['clusters']
    if not cluster_names:
        print("No EKS clusters found in the specified region.")
        return ["No EKS clusters found in the specified region."]

    return cluster_names


def get_cluster_info(cluster_name,access_key, secret_key, region_name):
    eks_client = eks_authentication(access_key, secret_key, region_name)
    session = boto3.Session(access_key, secret_key, region_name)
    try:
        cluster_info = eks_client.describe_cluster(name=cluster_name)['cluster']
        return {
            'Cluster Name': cluster_info['name'],
            'Region': session.region_name,
            'Kubernetes Version': cluster_info['version'],
            'Cluster Endpoint Access': cluster_info['endpoint'],
            'IAM Role': cluster_info['roleArn'],
            'RBAC enabled': cluster_info['resourcesVpcConfig']['endpointPublicAccess'],
            'Internet Gateways': get_internet_gateways(cluster_info['resourcesVpcConfig']['vpcId'],access_key, secret_key, region_name),
            'VPC Name': get_vpc_name(cluster_info['resourcesVpcConfig']['vpcId'],access_key, secret_key, region_name),
            'Subnet Name': get_subnet_names(cluster_info['resourcesVpcConfig']['subnetIds'],access_key, secret_key, region_name),
            'Security Group Name': get_security_group_names(cluster_info['resourcesVpcConfig']['securityGroupIds'],access_key, secret_key, region_name),
        }
    except Exception as e:
        print(f"Error retrieving information for cluster {cluster_name}: {e}")
        return ["Error retrieving information for cluster {cluster_name}"]
    
def list_nodegroup(cluster_name,access_key, secret_key, region_name):
     eks_client = eks_authentication(access_key, secret_key, region_name)
     try:
        nodegroup_names = eks_client.list_nodegroups(clusterName=cluster_name)['nodegroups']
        return nodegroup_names
    
     except Exception as e:
        print(f"Error retrieving node groups: {e}")
        return ["Error retrieving node groups"]

def get_nodegroup_info(nodegroup_info, access_key, secret_key, region_name):
        eks_client = eks_authentication(access_key, secret_key, region_name)
        node_count = nodegroup_info['scalingConfig']['desiredSize']
        min_node_count = nodegroup_info['scalingConfig']['minSize']
        max_node_count = nodegroup_info['scalingConfig']['maxSize']
        instance_types = ', '.join(nodegroup_info['instanceTypes'])
        ami_id = nodegroup_info.get('amiType', 'N/A') 
        key_pair_name = nodegroup_info.get('remoteAccess', {}).get('ec2SshKey', 'N/A')
        max_pods_per_node = nodegroup_info.get('maxPods', 'N/A')
        disk_size = nodegroup_info.get('diskSize', 20)  
        os_disk_type = 'gp2' if ami_id.startswith('AL2') else 'gp3'  
        iam_role_arn = nodegroup_info['nodeRole']
        Node_Labels = eks_client.list_tags_for_resource(resourceArn=nodegroup_info['nodegroupArn']).get('tags', {})

        return {
            "Node Group Name": nodegroup_info['nodegroupName'],
            "Cluster Name": nodegroup_info['clusterName'],
            "Node Count": node_count,
            "Min Node Count": min_node_count,
            "Max Node Count": max_node_count,
            "Instance Types": instance_types,
            "AMI ID": ami_id,
            "Key Pair Name": key_pair_name,
            "Max Pods per Node": max_pods_per_node,
            "OS Disk Type": os_disk_type,
            "OS Disk Size (GB)": disk_size,
            "IAM Role ARN": iam_role_arn,
            "Node Labels/Tags": Node_Labels
        }


def get_internet_gateways(vpc_id,access_key, secret_key, region_name):
    ec2_client = ec2_authentication(access_key, secret_key, region_name)
    response = ec2_client.describe_internet_gateways()
    gateways = [gw['InternetGatewayId'] for gw in response['InternetGateways'] if vpc_id in [att['VpcId'] for att in gw.get('Attachments', [])]]
    return gateways

def get_vpc_name(vpc_id,access_key, secret_key, region_name):
    ec2_client = ec2_authentication(access_key, secret_key, region_name)
    vpc = ec2_client.describe_vpcs(VpcIds=[vpc_id])['Vpcs'][0]
    return vpc['Tags'][0]['Value'] if 'Tags' in vpc and len(vpc['Tags']) > 0 else 'N/A'

def get_subnet_names(subnet_ids,access_key, secret_key, region_name):
    ec2_client = ec2_authentication(access_key, secret_key, region_name)
    subnets = ec2_client.describe_subnets(SubnetIds=subnet_ids)['Subnets']
    return [subnet['Tags'][0]['Value'] if 'Tags' in subnet and len(subnet['Tags']) > 0 else 'N/A' for subnet in subnets]

def get_security_group_names(security_group_ids,access_key, secret_key, region_name):
    ec2_client = ec2_authentication(access_key, secret_key, region_name)
    security_groups = ec2_client.describe_security_groups(GroupIds=security_group_ids)['SecurityGroups']
    return [sg['GroupName'] for sg in security_groups]

def retrieve_eks_configuration(access_key, secret_key, region_name):
    cluster_names = list_eks_cluster(access_key, secret_key, region_name)
    no_cluster_message = ["No EKS clusters found in the specified region."]
    if cluster_names == no_cluster_message:
        eks_cluster_config = ["No clusters found"]
        eks_nodegroup_config = ["No Nodegroups found"]
        return eks_cluster_config, eks_nodegroup_config
    else:
        eks_cluster_config = []
        eks_nodegroup_config = []
        for cluster_name in cluster_names:
            cluster_info = get_cluster_info(cluster_name,access_key, secret_key, region_name)
            eks_cluster_config.append(cluster_info)
            node_group_names = list_nodegroup(cluster_name,access_key, secret_key, region_name)
            eks_client = eks_authentication(access_key, secret_key, region_name)
            
            for nodegroup_name in node_group_names:
                response = eks_client.describe_nodegroup(
                clusterName=cluster_name,
                nodegroupName=nodegroup_name
            )
            nodegroup_info = response['nodegroup']

            nodegroup_info = get_nodegroup_info(nodegroup_info,access_key, secret_key, region_name)
            eks_nodegroup_config.append(nodegroup_info)

            return eks_cluster_config , eks_nodegroup_config


